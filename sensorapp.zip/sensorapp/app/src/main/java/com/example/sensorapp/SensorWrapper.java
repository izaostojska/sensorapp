package com.example.sensorapp;

import android.hardware.Sensor;

public class SensorWrapper {
    private Sensor sensor;
    private int index;
    private boolean selectable;

    public SensorWrapper(Sensor sensor, int index, boolean selectable) {
        this.sensor = sensor;
        this.index = index;
        this.selectable = selectable;
    }

    public Sensor getSensor() {
        return sensor;
    }

    public int getIndex() {
        return index;
    }

    public boolean isSelectable() {
        return selectable;
    }

    public void setSelectable(boolean selectable) {
        this.selectable = selectable;
    }
}

